#!/bin/bash

# Initialize the counter
counter=0

while true; do
    
    # Run vanitysearch and wait for it to finish
    ./vanitysearch
    
    # Check if the file "OK" exists after vanitysearch finishes
    if [ ! -e OK ]; then
        echo "File 'OK' not found. Exiting the loop..."
        break
    fi
    
    # Increment the counter
    ((counter++))
    
    # Print the message with the counter
    echo "Loops completed this session: $counter"
    
done

# Wait for any key press before exiting
read -n 1 -s -r -p "Client stopped. Press any key to continue
